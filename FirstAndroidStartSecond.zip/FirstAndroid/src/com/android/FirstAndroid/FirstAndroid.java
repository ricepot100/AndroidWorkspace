package com.android.FirstAndroid;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.content.Intent ;
import android.content.ServiceConnection ;


public class FirstAndroid extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	Log.v("tiantian", "FirstAndroid.onCreate()");
    	super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        Intent testActivityIntent = new Intent();  
        Log.v("tiantian", "In FirstAndroid.onCreate() to startActivity SecondAndroid" ) ;
        testActivityIntent.setAction("com.android.1234F");    
        startActivity(testActivityIntent); 

        
        testActivityIntent = null ;
        testActivityIntent = new Intent();   
        testActivityIntent.setAction("android.intent.action.START_PCM_PLAY_SERVICE") ;
        
        Log.v("tiantian", "In FirstAndroid.onCreate() to stopService android.intent.action.START_PCM_PLAY_SERVICE ");
        stopService(testActivityIntent);
        Log.v("tiantian", "In FirstAndroid.onCreate() to startService android.intent.action.START_PCM_PLAY_SERVICE ");
        startService(testActivityIntent);     
       
    }
}