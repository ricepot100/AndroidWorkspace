package com.android.SecondAndroid;



import android.app.Service;
import android.content.Intent;
import android.media.AudioManager;

import android.media.AudioTrack; 
import android.media.AudioFormat;

import android.os.IBinder;

import android.util.Log;


import java.io.FileInputStream ;
import java.io.IOException;

/**
 * @hide Synthesizes speech from text. This is implemented as a service so that
 *       other applications can call the TTS without needing to bundle the TTS
 *       in the build.
 *
 */
public class ServiceInSecondAndroid extends Service  {

	private AudioTrack at = null  ;
    @Override
    public void onCreate() 
    {
        super.onCreate();
        Log.v("tiantian", "thirdAndroid.onCreate()");
       
        if( at != null )
        {
        	at.release() ;
        }
		at = new AudioTrack( AudioManager.STREAM_MUSIC , 44100 , AudioFormat.CHANNEL_OUT_STEREO ,AudioFormat.ENCODING_PCM_16BIT , 44100*4*25,   AudioTrack.MODE_STATIC ) ;
		if( at!= null )
			Log.v("tiantian", "AudioTrack success create");
		FileInputStream f1 ;
		try
		{
			f1=new FileInputStream("/sdcard/gaosu_44100_stereo.pcm");
		} 
		catch ( IOException e ) 
		{
			Log.v("tiantian", "gaosu_44100_stereo.pcm not exist");
			return;
		}
		byte[] payload = new byte[44100*4*25] ;
		Log.v("tiantian", "payload ok");
		int len ;
		try 
		{
			len = f1.read(payload, 0, 44100*4*25);
		}
		catch (IOException e )
		{
			Log.v("tiantian", "fail to read gaosu_44100_stereo.pcm");
			return ;
		}
		try
		{
			f1.close();
		}
		catch (IOException e )
		{
			Log.v("tiantian", "close error");
			return;
		}
		at.write(payload,0,len);
		at.play();
		return ;
    }
    
    public IBinder onBind(Intent intent) {
    	Log.v("tiantian", "onBind");
       return null;
   
    }
    

}